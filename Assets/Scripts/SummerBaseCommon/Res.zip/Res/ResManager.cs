﻿using System;
using Summer;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// TODO
///     1.后缀名的解决方案
///     2.加载的资源和加载的路径是两回事
/// Bug 由于提供了全路径，所以导致他加载的时候所在的cache是会出问题的， 这就需要对资源做严格的区分
/// Bug 按照资源的类型严格区分，同时屏蔽掉quanming路径这个类型
/// 可能是概念性bug，之前的思路出现了错误想法，高内聚，低耦合思路
/// 本身资源加载的作用就是资源加载器
/// 提供基础的作用如下
/// 1.加载资源
/// 2.控制同时加载次数
/// 3.控制同一时间多次假期
/// 等相关问题
/// 
/// 那么针对资源具体的卸载。就需要根据不同类型资源不同的卸载策略了。所以quanming这个不一定是bug问题
/// 
/// TODO 2018.10.12
///     基本的资源工具 一般需要3层
///     1. 顶层，针对不同的资源有不同的资源策略，类似缓存池、Sprite的LRU算法
///     2. 中层的Resloader 资源加载，缓存最大加载限制，同时加载限制等等，不用关心到底是Resource/AssetDataBase/AssetBundle
///     3. Resource/AssetDataBase/AssetBundle 这一层 基本上忽略本地加载/和Resources 关注下AssetBundle的缓存
/// </summary>
public class ResManager : I_ResManager
{
    public static ResManager instance = new ResManager();
    public Texture _bgLoading;                                      // 异步加载时的图片资源
    public Sprite _defaultSprite;
    public ResLoader _resLoader;

    public ResManager()
    {
        _resLoader = ResLoader.Instance;
        _init();
    }

    #region 引用计数

    public OldRefInfo _internal_ref_increase(string resPath, GameObject obj)
    {
        OldRefInfo counter = obj.GetComponent<OldRefInfo>();
        if (counter == null)
            counter = obj.AddComponent<OldRefInfo>();

        //counter.AddRef(resPath);
        return counter;
    }

    public OldRefInfo _internal_ref_decrease(GameObject obj)
    {
        OldRefInfo counter = obj.GetComponent<OldRefInfo>();
        /*if (counter != null)
            counter.RemoveRef();*/
        return counter;
    }

    #endregion

    #region Load类型 Texture Audio Animation GameObject 

    #region Texture图片加载

    public Texture LoadTexture(string resPath)
    {
        Texture texture = _resLoader.LoadAsset<Texture>(resPath);
        return texture;
    }

    public Texture LoadTexture(RawImage img, string resPath)
    {
        GameObject obj = img.gameObject;
        Texture texture = _resLoader.LoadAsset<Texture>(resPath);

        if (texture != null)
        {
            _internal_ref_decrease(obj);
            img.texture = texture;
            _internal_ref_increase(resPath, obj);
        }
        else
        {
            img.texture = _bgLoading;
        }
        return texture;
    }

    public void LoadTextureAsync(RawImage img, string resPath, Action<Texture> callback = null)
    {
        GameObject obj = img.gameObject;


        img.texture = _bgLoading;
        Action<Texture> defaultCallback = delegate (Texture texture)
        {
            if (texture != null)
            {
                _internal_ref_decrease(obj);
                img.texture = texture;
                //img.SetNativeSize();
                _internal_ref_increase(resPath, img.gameObject);
            }
        };
        _resLoader.LoadAssetAsync(resPath, callback, defaultCallback);
    }

    public void ResetDefaultTexture(RawImage img)
    {
        img.texture = _bgLoading;
    }

    #endregion

    #region Sprite

    public bool LoadSprite(Image img, string resPath, string oldResPath = null)
    {
        if (img == null) return false;

        Sprite sprite = _resLoader.LoadAsset<Sprite>(resPath);
        if (sprite != null)
        {
            img.sprite = sprite;
        }
        return false;
    }

    public bool UnLoadSprite(Image img)
    {
        if (img.sprite == null) return false;
        bool result = _resLoader.UnLoadRef(img);
        if (result)
            img.sprite = _defaultSprite;
        return result;
    }

    public void LoadSpriteAsync(Image img, string resPath, Action<Sprite> complete = null)
    {
        if (img == null) return;
        Action<Sprite> action = delegate (Sprite sprite)
        {
            img.sprite = sprite;
            if (complete != null && sprite != null)
                complete.Invoke(sprite);
        };
        _resLoader.LoadAssetAsync(resPath, action);
    }


    #endregion

    #region Audio

    #endregion

    #region Animation

    public AnimationClip LoadAnimationClip(string resPath)
    {
        AnimationClip animationClip = _resLoader.LoadAsset<AnimationClip>(resPath);
        return animationClip;
    }

    public void LoadAnimationClipAsync(string resPath, Action<AnimationClip> complete)
    {
        _resLoader.LoadAssetAsync(resPath, complete);
    }

    #endregion

    #region GameObject

    public GameObject LoadPrefab(string resPath, bool isCopy = true)
    {
        GameObject prefabGameobj = _resLoader.LoadAsset<GameObject>(resPath);
        if (prefabGameobj == null) return null;
        if (!isCopy)
        {
            return prefabGameobj;
        }
        GameObject instantisteGameobj = GameObjectHelper.Instantiate(prefabGameobj);
        _internal_ref_increase(resPath, instantisteGameobj);
        return instantisteGameobj;
    }

    public void LoadPrefabAsync(string resPath, Action<GameObject> complete = null)
    {

        Action<GameObject> action = delegate (GameObject gameObject)
        {
            GameObject instantisteGameobj = GameObjectHelper.Instantiate(gameObject);
            _internal_ref_increase(resPath, instantisteGameobj);
            if (complete != null)
                complete.Invoke(instantisteGameobj);
        };
        _resLoader.LoadAssetAsync(resPath, action);
    }

    #endregion

    #region bytes

    public string LoadText(string resPath)
    {
        TextAsset textAsset = _resLoader.LoadAsset<TextAsset>(resPath);
        return textAsset.text;
    }

    public byte[] LoadByte(string resPath)
    {
        TextAsset textAsset = _resLoader.LoadAsset<TextAsset>(resPath);
        return textAsset.bytes;
    }
    #endregion

    #endregion

    #region public

    #endregion

    #region private

    public void _init()
    {
        _bgLoading = Resources.Load<Texture>("default/bg_loading");
        ResLog.Assert(_bgLoading != null, "找不到默认的图片信息");

        Resources.Load<Sprite>("default/default_sprite");
    }

    #endregion



}


