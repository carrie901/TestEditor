﻿using UnityEngine.UI;

namespace Summer
{
    public class RefTexutreCounter : OldRefInfo
    {
        public RawImage _target;
        /*public override void AddExcute()
        {
            _target = gameObject.GetComponent<RawImage>();
        }

        public override void RemoveExcute()
        {
            if (_target == null || _target.texture == null) return;
            _target.texture = null;
        }*/
    }
}

